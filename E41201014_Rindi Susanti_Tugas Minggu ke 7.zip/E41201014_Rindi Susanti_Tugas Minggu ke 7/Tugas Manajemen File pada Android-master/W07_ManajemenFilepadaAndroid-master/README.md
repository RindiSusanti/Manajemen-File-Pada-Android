Nama : Rindi Susanti

NIM : E41201014

Prodi/Jurusan : Teknik Informatika

Gol : A Bondowoso

TUGAS MINGGU 7 (Manajemen File pada Android)